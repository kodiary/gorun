<?php $this->beginContent('/layouts/main'); ?>

	<div id="content">
	<?php echo $content; ?>
	</div><!-- content -->
<!--
<div class="span-5 last">
	<div id="sidebar">
	this is side bar
	</div>
</div>
-->
<?php $this->endContent(); ?>