<div class="sidebar col-md-3">
  <?php echo $this->renderPartial('/sidebar/_menu', false, true); ?>
</div>
<div class="col-md-9 right-content profile_detail">
    <div >
        <h1 class="bold">YOUR FIRST LOGIN LIKE EVER!</h1>
        <strong><span class="blue">Welcome to Go Run!</span> </strong>
        <br/>
        Your athletic profile has been created - complete the last bits now or later...
    </div>
    <div class="clearfix"></div>
    <hr />
        <br />
        <br />
        <br />
        <br />
    <hr />
    
    <div class="form-group col-md-10 center">
    <form action="" method="post">
        <input type="submit" name="first_login" value="Save Changes" class="btn btn-default bgblue " />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="button" value="Cancel" class="btn btn-default " />
    </form>
    </div>
</div>