<h2>Your Profile</h2>
<div class="dashboard_menu">
    <ul>
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/dashboard" class="active">Profile Details</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/dashboard">Password</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/dashboard">Settings</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/dashboard">Your Clubs</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/dashboard">Your Results</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/dashboard">Your Race Reviews</a></li>
    </ul>
</div>
<a href="#" class="race_wallet">RACE WALLET - <span class="blue">R0.00</span></a>
<a href="#" class="submit-event">Submit your event &nbsp; <span class="fa fa-plus"></span></a> 